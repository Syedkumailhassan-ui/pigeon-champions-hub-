PIGEON CHAMPIONS HUB — Free starter website
============================================

Files:
- index.html: complete responsive website (HTML/CSS/JavaScript in one file)

Run locally:
1. Extract the ZIP.
2. Open index.html in Chrome or another browser.
3. Try tournament search, city filter, registration form, add-tournament form, club suggestion and buyer enquiry.

Important limitations:
- This is a front-end demo. It does not have a database, real login, persistent submissions, email sending, or payments.
- Sample tournaments, names and dates are illustrative. Verify or replace them before publishing.
- The forms show demo messages only. They do not send data to anyone.
- For a real production version, add a backend/database, server-side validation, privacy notice, anti-spam protection, and secure admin access.

Free publishing outline:
1. Create a GitHub account and a new public repository.
2. Upload index.html to the repository root.
3. In repository Settings > Pages, enable publishing from the main branch/root (GitHub UI wording may change).
4. Wait for the published URL, then test on mobile and share the demo.
Alternative: Netlify or Cloudflare Pages can host a static site; check their current free-plan terms.

Selling outline:
1. Replace sample data and add your own branding/contact details.
2. Show the live demo to pigeon clubs and event organizers.
3. Be transparent that this is a starter demo and that backend features are not included.
4. Agree in writing on scope, price, delivery date and ownership.
5. Confirm payment before transferring files/domain access. Never share personal passwords.
6. For a more valuable sale, get real clubs to test it and collect evidence of demand. Do not claim revenue/users you do not have.
